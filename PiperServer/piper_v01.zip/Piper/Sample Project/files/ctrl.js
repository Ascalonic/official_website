const scr_width = 600; const scr_height = 300;
const ground_height = 75; const jump_limit = 35;
var dist = 0; var dir = -1;
const char_pos = 100;

var obst_over = 0;

var paused = false;

var score = 0;

var jump_speed = 2; var obst_speed = 2;

var obstacles = [];

function init () {
	window.requestAnimationFrame(draw); 
	setTimeout(addObstacle, 2000);
}

function drawScore(ctx)
{
	ctx.font = "30px Consolas";
	ctx.fillStyle = "green";
	ctx.fillText(score, scr_width - 100, 100);
	
	ctx.font = "20px Consolas"
	ctx.fillStyle = "blue";
	ctx.fillText('The adventures of Austin Ignatius', 10, 20);

}

function drawGameOver(ctx)
{
	ctx.font = "35px Consolas";
	ctx.fillStyle = "red";
	ctx.textAlign = "center";
	ctx.fillText("GAME OVER", scr_width/2, 100);
}


function detectCollision()
{
	var start = obst_over; 
	
	for(var i = start;i<obstacles.length;i++)
	{
		if(scr_width - obstacles[i].pos <= char_pos + 15 && 
								scr_width - obstacles[i].pos >= char_pos &&
								dist <= obstacles[i].height)
		{
			return true;						
		}
	}
	
	return false;
}

function draw() {
	var ctx = document.getElementById('vp-canvas').getContext('2d');
	
	ctx.clearRect(0, 0, scr_width, scr_height);
	ctx.save();	
		
	if(paused)
	{
		drawGameOver(ctx);
		jump_speed = 0; obst_speed = 0;
	}
	else
	{
		setDistanceFromGround();
	}
	
	drawCharacter(ctx);
	
	drawGround(ctx, ground_height);
	drawObstacles(ctx);
	
	drawScore(ctx);
	
	if(!paused && detectCollision())
	{
		paused = true;
	}	

	// animate by redrawing
	window.requestAnimationFrame(draw);
}

function setDistanceFromGround()
{
	if(dir == 1 && dist< jump_limit)
	{
		dist += jump_speed;
	}
	else if(dir == 1 && dist >= jump_limit)
	{
		dist = jump_limit;
		dir = 0;
	}
	else if(dir == 0 && dist > 0)
	{
		dist -= jump_speed;
	}
	else if(dir == 0 && dist <=0)
	{
		dist = 0;
		dir = -1;
	}
	
}

function addObstacle()
{
	obstacles.push({height: 10, pos: 0});
	setTimeout(addObstacle, 3000);
}

function drawObstacles(ctx)
{
	var start = obst_over; 
	
	for(var i = start;i<obstacles.length;i++)
	{
		var width = 15; var height = 40;
		ctx.fillStyle = "green";
		ctx.fillRect(scr_width - obstacles[i].pos - width/2, 
				scr_height - ground_height - obstacles[i].height, width, height);
		obstacles[i].pos+=obst_speed;
		
		if(scr_width - obstacles[i].pos < char_pos)
		{
			score = i;
			obst_speed = 2 + score/5;
			jump_speed = obst_speed;
		}
		
		if(scr_width - obstacles[i].pos <= 0)
		{
			obst_over = i;
		}
	}
}

function drawCharacter(ctx)
{
	var width = 15; var height = 40;
	ctx.fillStyle = "blue";
	ctx.fillRect(char_pos - width/2, scr_height - ground_height - height - dist, width, height);
}

function drawGround(ctx, height)
{
	ctx.fillStyle = "green";
	ctx.fillRect(0, scr_height - height, scr_width, height);
}

document.addEventListener('keydown', function(event) {
	if(event.keyCode == 38 && dir == -1) {
		dir = 1;
	}
});

init();