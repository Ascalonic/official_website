using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

using PiperServer;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            HTTPServer p = new HTTPServer(80, "files/");
			p.addHandler("/test", Requestype.GET, testResp); //Adding a GET handler for /test
			p.listen();
        }
		
		public static ServerResponse testResp(RequestInfo info)
		{
			return(RespBuilder.simpleHTML(@"
				<html>
					<head>
						<title>Sample Test Page</title>
					</head>
					<body>
						<p>This page is a GET response from Piper</p>
					</body>
				</html>
			"));
		}
    }
}
